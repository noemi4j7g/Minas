package MainJuego;

/**
 *
 * @author arquitectura de software I 2016
 */
public interface JuegoAbierto {
    public void observadoActualizado( JuegoObservado objObservado );
   
}

